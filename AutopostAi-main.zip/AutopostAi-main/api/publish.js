export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    const { raw_text, platforms = [], action } = req.body;
    
    // Agent Router API Key Directly Integrated
    const AGENT_ROUTER_KEY = 'sk-kvLysXbvqMfJhJCkW1LAC7SAKdbHAhFtaKS4c5VOdNhzdlAu';

    if (!raw_text) {
        return res.status(400).json({ error: 'Text content is required' });
    }

    try {
        // STEP 2: AI ADAPT USING AGENT ROUTER API
        if (action === 'adapt') {
            let adaptedText = raw_text;

            const aiResponse = await fetch('https://agentrouter.org/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${AGENT_ROUTER_KEY}`
                },
                body: JSON.stringify({
                    model: 'gpt-4o-mini',
                    messages: [
                        {
                            role: 'system',
                            content: 'You are an expert social media content creator. Take the user message/content and reformat it for social media (Facebook, Instagram, Telegram). Add engaging line breaks, emojis, bullet points, a clear Call To Action (CTA), and relevant trending hashtags. Do not add conversational fluff, only output the ready-to-post text.'
                        },
                        {
                            role: 'user',
                            content: raw_text
                        }
                    ]
                })
            });

            const aiData = await aiResponse.json();

            if (aiData.choices && aiData.choices[0]?.message?.content) {
                adaptedText = aiData.choices[0].message.content;
            } else if (aiData.error) {
                console.error("Agent Router Error:", aiData.error);
            }

            return res.status(200).json({ 
                success: true, 
                formatted_content: adaptedText 
            });
        }

        // STEP 4: REAL PUBLISH DISPATCH
        const publishResults = [];

        // Telegram Integration (if env variables set)
        if (platforms.includes('telegram') && process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID) {
            const tgRes = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    chat_id: process.env.TELEGRAM_CHAT_ID,
                    text: raw_text
                })
            });
            const tgData = await tgRes.json();
            publishResults.push({ platform: 'telegram', success: tgData.ok });
        }

        return res.status(200).json({
            success: true,
            message: 'Post successfully published across channels!',
            results: publishResults
        });

    } catch (error) {
        return res.status(500).json({ 
            error: 'Server processing failed', 
            details: error.message 
        });
    }
}
