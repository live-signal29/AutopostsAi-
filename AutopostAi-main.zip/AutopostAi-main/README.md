# AutoPost.ai

AutoPost.ai ek smart multi-platform social media publishing application hai. Isme Agent Router AI integration ke zariye content auto-optimize hota hai aur Facebook, Instagram, Telegram, LinkedIn, aur X (Twitter) par ek sath publish hota hai.

## Features

- **Clean Dashboard UI:** Administrative clutter ke bina streamlined layout.
- **Agent Router AI Integration:** High-quality AI adaptation ke sath optimized social media captions.
- **Multi-Platform Publishing:** Direct dispatch pipeline for multiple social channels.
- **Step-by-Step Workflow:** 1. Upload Media / Text
  2. AI Adapt
  3. Real-time Preview
  4. Live Publish

## Setup & Deployment

1. Repository clone karein:
   ```bash
   git clone [https://github.com/live-signal29/AutopostAi.git](https://github.com/live-signal29/AutopostAi.git)
